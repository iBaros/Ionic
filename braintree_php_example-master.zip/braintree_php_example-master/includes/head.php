<head>
    <title>BraintreePHPExample</title>
    <link rel=stylesheet type=text/css href="css/app.css">
    <link rel=stylesheet type=text/css href="css/overrides.css">
    <script src="javascript/vendor/jquery-2.1.4.min.js"></script>
    <script src="javascript/vendor/jquery.lettering-0.6.1.min.js"></script>
    <script src="javascript/demo.js"></script>
</head>
